export class Main {
    public printFromMain(session: any): void {
        session.send("Printing from main");
    }

    //public runCommand()
}