import * as w from 'vso-node-api/WebApi';
import * as lim from 'vso-node-api/interfaces/LocationsInterfaces';
import * as vsts from 'vso-node-api';


function getToken(): string {
    return "rvpliepu2qeaapecwmghtpmwi3ztk5gen7yklu7vcr6wnnrt5wbq";
}

export function getAccountUrl(): string {
    return "http://nehal:8080/tfs/DefaultCollection/";
}

export function getPRojectIdFromName() {
    
    return "1";
    
}


export async function getConnection(): Promise<w.WebApi> {
    return await this.getApi(getAccountUrl());
}

export async function getApi(serverUrl: string): Promise<w.WebApi> {

    return new Promise<w.WebApi>(async (resolve, reject) => {
        try {
            let token = getToken();
            let authHandler = w.getPersonalAccessTokenHandler(token);
            let option = undefined;

            let vsts: w.WebApi = new w.WebApi(serverUrl, authHandler, option);
            let connData: lim.ConnectionData = await vsts.connect();
            console.log('Hello ' + connData.authenticatedUser.providerDisplayName);
            console.log("Hope you are doing good")
            resolve(vsts);
        }
        catch (err) {
            reject(err);
        }
    });
}