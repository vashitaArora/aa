import * as w from 'vso-node-api/WebApi';
import { WorkItem } from 'vso-node-api/interfaces/WorkItemTrackingInterfaces';
//var register = require('../register')

export var createbug1 = 5;
console.log("inside command")

export async function createBug(vstsConnection: w.WebApi,messageJson: any) {
    let witApi = await vstsConnection.getWorkItemTrackingApi();
    let wijson = [{ "op": "add", "path": "/fields/System.Title", "value": messageJson.bugTitle }];
 
    let witype: string = "Bug";

    return new Promise<string>(async(resolve, reject)  => {
        console.log("about to create a json")
        console.log(wijson)
        witApi.createWorkItem(null, wijson, messageJson.project, witype).then((wit: WorkItem) => {
            resolve("Created workitem " + wit.id);
        },
    (err) => {

    console.log("error encountered")
    reject(err)
    });
});
}
//register.register("createBug", createBug);


