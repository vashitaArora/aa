
import * as connection from './connection'
import * as createBug from './createbug'

export class Main {
    public printFromMain(session: any): void {
        session.send("Printing from main");
    }

    private _vsts: any;

    public async initialize()
    { 
        console.log("setting up the initial connection to vsts")
        // setup the initial connection to vsts
        this._vsts = await connection.getConnection();
        
    }

    constructor() {
        if(!this._vsts)
            this.initialize();
    }

    public executeCommand(session: any) {
        console.log("message reached VSS")
        let message = session.message.text
        session.send("message reached VSS");
        console.log("message is : " + message)
        
            let messageJson = {
                project : "1",
                bugTitle: "bug 1",
            }
            createBug.createBug(this._vsts, messageJson).then((response: any) => {
                session.send(response);
            },
            (error) => {
                session.send(error.message);
            }
        );
        
    }
    //public runCommand()
}